import { useSystemStore } from '../stores/system-store';

export const API_TIMEOUT = 5000;

export async function checkApiHealth(url: string): Promise<boolean> {
  if (!url) return false;
  
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), API_TIMEOUT);
    
    // We try to fetch the health endpoint or just the base URL
    // Depending on the backend implementation, we might need a specific endpoint
    const cleanUrl = url.endsWith('/') ? url.slice(0, -1) : url;
    const response = await fetch(`${cleanUrl}/api/public-settings`, {
      signal: controller.signal,
      headers: {
        'Cache-Control': 'no-cache'
      }
    });
    
    clearTimeout(timeoutId);
    return response.ok;
  } catch (error: any) {
    // Only log if it's not a timeout/abort to keep console clean
    if (error.name !== 'AbortError') {
      console.warn(`API Health Check Failed for ${url}:`, error.message || error);
    }
    return false;
  }
}

export async function syncSystemState() {
  const store = useSystemStore.getState();
  const { apiUrl, setupCompleted } = store;
  
  if (!setupCompleted || !apiUrl) {
    store.setSystemState('setup');
    return;
  }
  
  store.setSystemState('connecting');
  const isHealthy = await checkApiHealth(apiUrl);
  
  if (isHealthy) {
    store.setApiConnected(true);
    store.setSystemState('online');
  } else {
    store.setApiConnected(false);
    store.setSystemState('offline');
  }
  
  store.updateLastCheck();
}
